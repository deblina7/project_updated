<?php
session_start();
session_destroy();
?>
<Script>
location.replace("account.php");
alert("Goodbye see you soon!")
</Script>